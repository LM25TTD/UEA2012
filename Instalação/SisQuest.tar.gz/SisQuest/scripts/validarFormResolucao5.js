function enviardados(){



if(document.dados.area.value=="0" )

{

alert( "Preencha o Area corretamente!" );

document.dados.area.focus();

return false;

}

if(document.dados.disciplina.value=="0" )

{

alert( "Preencha a Disciplina corretamente!" );

document.dados.disciplina.focus();

return false;

}

if(document.dados.assunto.value=="0")

{

alert( "Preencha o Assunto corretamente!" );

document.dados.assunto.focus();

return false;

}


return true;

}