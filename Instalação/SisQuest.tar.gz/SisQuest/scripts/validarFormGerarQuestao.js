function enviardados(){

if (document.dados.altSelect[0].checked == false && document.dados.altSelect[1].checked==false && document.dados.altSelect[2].checked==false && document.dados.altSelect[3].checked==false && document.dados.altSelect[4].checked==false)
{
		alert("Selecione alguma das alternativas!!.");
		return false;
}


	return true;
}
