<?php
include ("../../dao/seguranca.php");
include ("../../dao/areaDao.php");


$resultadoTotal = areaConsulta($_SG['link']);


?>