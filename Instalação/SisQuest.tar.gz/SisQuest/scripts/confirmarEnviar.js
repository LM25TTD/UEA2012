function confirmarEnviar(){



if(document.dados.input_nome.value=="" || document.dados.input_data.value=="" || document.dados.input_tel.value=="" || document.dados.input_email.value=="" || document.dados.input_rua.value=="" || document.dados.input_numero.value=="" || document.dados.input_bairro.value=="" || document.dados.input_numero.value=="" || document.dados.input_bairro.value=="" || document.dados.input_cidade.value=="" || document.dados.input_estado.value=="" || document.dados.input_cep.value=="" )

{

alert( "Preencha os seus dados corretamente!" );


return false;

}

return confirm("Você tem certeza que deseja alterar os seus dados??");

}