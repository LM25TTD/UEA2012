<?php
include("../../dao/seguranca.php");
include("../../dao/disciplinaDao.php");



$resultadoTotal = disciplinaConsulta($_SG['link']);

$resultadoAreas = resultadoAreasConsulta($_SG['link']);

function resultadoAreasConsultaEdicaoServico($id,$link){ 
	return resultadoAreasConsultaEdicao($id,$link);
}

function disciplinaConsultaEdicaoServico($id, $link){
	return disciplinaConsultaEdicao($id, $link);
}


?>