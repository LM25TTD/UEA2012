<?php
include "seguranca.php";
/**
 *Chama a funcão que limpa as variáveis de seção
 */
expulsaVisitante();
?>
