<?php
include ("../../dao/seguranca.php");
include ("../../dao/questaoDao.php");





$resultado= questaoConsultaContador($_SG['link']);
 


function carregaQuestaoEdicaoServico($id,$link){
	return mysql_fetch_array(questaoConsultaEdicao($id, $link));
}


?>